const express = require('express')
const bodyParser = require('body-parser');
const AdminRoutes = require('./routes/admin.routes');
const BuyerRoutes = require('./routes/buyer.routes');
const SellerRoutes = require('./routes/seller.routes');
const app = express()
const errorHandler = require('@libs/error-handler/error-handler');
const checkApiKey = require('@libs/JWT/apikey-auth-api');
const logger = require('@libs/logger/logger');
const path = require('path');
app.use(bodyParser.json())
const cors = require('cors');
const setupStaticFiles = require('@libs/folders-paths/setup-static-files');
// API AUTHENTICATION – ACCESS TOKEN CHECKING FOR EACH REQUEST
const AdminStartAuthApi = require("@libs/JWT/admin-auth-api");
const BuyerStartAuthApi = require("@libs/JWT/buyer-auth-api");
const SellerStartAuthApi = require("@libs/JWT/seller-auth-api");

app.use(cors()); // Enables CORS for all origins and all routes
// --------------------------------------
// ENABLE CORS FOR SPECIFIC ORIGINS
// --------------------------------------
// const allowedOrigins = [
//    'http://localhost:3000',
//    'http://localhost:3000',
//    'https://yourdomain.com'
// ];

// app.use(cors({
//    origin: function (origin, callback) {
//       if (!origin || allowedOrigins.includes(origin)) {
//          callback(null, true);
//       } else {
//          callback(new Error('Not allowed by CORS'));
//       }
//    },
//    methods: ['GET', 'POST', 'PUT', 'DELETE'],
//    credentials: true
// }));

// 🔹 Map static files
setupStaticFiles(app);


// PUBLIC ROUTES
const AdminPublicRoutes = require('./routes/admin.public.routes');
const BuyerPublicRoutes = require('./routes/buyer.public.routes');
const SellerPublicRoutes = require('./routes/seller.public.routes');

/* --------------------------------
   PUBLIC ROUTES (NO AUTH)
--------------------------------- */
app.use('/api', checkApiKey, AdminPublicRoutes);
app.use('/buyer', checkApiKey, BuyerPublicRoutes);
app.use('/seller', checkApiKey, SellerPublicRoutes);

// // /* -------------------------------
// //    PROTECTED ROUTES wITH ACCESSTOKEN 
// // -------------------------------- */
// app.use('/api', checkApiKey, AdminStartAuthApi, AdminRoutes);
// app.use('/buyer', checkApiKey, BuyerStartAuthApi, BuyerRoutes);
// app.use('/seller', checkApiKey, SellerStartAuthApi, SellerRoutes);

// Assign assigned_to middleware
const assignAssignedTo = (req, res, next) => {
    if (req.method === "POST" && req.body) {
        req.body.assigned_to = req.body.created_by || req.body.assigned_to;
    }
    next();
};


// /* -------------------------------
//    PROTECTED ROUTES wITH ACCESSTOKEN 
// -------------------------------- */
app.use('/api', checkApiKey, assignAssignedTo, AdminRoutes);
app.use('/buyer', checkApiKey, BuyerRoutes);
app.use('/seller', checkApiKey, SellerRoutes);


/* -------------------------------
   GLOBAL ERROR HANDLER
-------------------------------- */
// app.use((err, req, res, next) => {
//     logger.error("GLOBAL ERROR:", err);

//     res.status(err.status || 500).json({
//         success: false,
//         message: err.message || "Server is down. Please try again later.",
//         error_code: err.error_code || "SERVER_ERROR"
//     });
// });

// GLOBAL ERROR HANDLER
app.use(errorHandler);

app.listen(3000, (err) => {
    if (err) {
        logger.error('Failed to start server:', err);
        process.exit(1);
    }
    logger.info('Server listening on port 3000');
});
