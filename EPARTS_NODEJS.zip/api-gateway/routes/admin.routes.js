require('module-alias/register');
const apiAccess = require('@libs/JWT/data-access-control-api.js');
const router = (() => require('express'))().Router();


router.use('/role', (req, res, next) => require('../admin-routes/roles.routes.js')(req, res, next));

router.use('/user-type', (req, res, next) => require('../admin-routes/user-type.routes.js')(req, res, next));

router.use('/user', (req, res, next) => require('../admin-routes/users.routes.js')(req, res, next));

router.use('/portal-user', (req, res, next) => require('../admin-routes/portal-user.routes.js')(req, res, next));

router.use('/country', (req, res, next) => require('../admin-routes/countries.routes.js')(req, res, next));

router.use('/state', (req, res, next) => require('../admin-routes/states.routes.js')(req, res, next));

router.use('/city', (req, res, next) => require('../admin-routes/cities.routes.js')(req, res, next));

router.use('/currency', (req, res, next) => require('../admin-routes/currency.routes.js')(req, res, next));

router.use('/setting', (req, res, next) => require('../admin-routes/settings.routes.js')(req, res, next));

router.use('/trading-type', (req, res, next) => require('../admin-routes/trading-types.routes.js')(req, res, next));

router.use('/product-type', (req, res, next) => require('../admin-routes/product-types.routes.js')(req, res, next));

router.use('/payment-mode', (req, res, next) => require('../admin-routes/payment-modes.routes.js')(req, res, next));

router.use('/registration-status', (req, res, next) => require('../admin-routes/registration-status.routes.js')(req, res, next));

router.use('/registration-fail-reason', (req, res, next) => require('../admin-routes/registration-fail-reasons.routes.js')(req, res, next));

router.use('/product-listing-status', (req, res, next) => require('../admin-routes/product-listing-status.routes.js')(req, res, next));

router.use('/rejection-reason', (req, res, next) => require('../admin-routes/rejection-reasons.routes.js')(req, res, next));

router.use('/category-request-status', (req, res, next) => require('../admin-routes/category-request-status.routes.js')(req, res, next));

router.use('/order-status', (req, res, next) => require('../admin-routes/order_statuses.routes.js')(req, res, next));

router.use('/parts-request-status', (req, res, next) => require('../admin-routes/parts_request_statuses.routes.js')(req, res, next));

router.use('/payment-status', (req, res, next) => require('../admin-routes/payment_statuses.routes.js')(req, res, next));

router.use('/quote-status', (req, res, next) => require('../admin-routes/quote_statuses.routes.js')(req, res, next));

router.use('/refund-status', (req, res, next) => require('../admin-routes/refund_statuses.routes.js')(req, res, next));

router.use('/shipment-status', (req, res, next) => require('../admin-routes/shipment_statuses.routes.js')(req, res, next));

router.use('/make-offer-status', (req, res, next) => require('../admin-routes/make_offer_status.routes.js')(req, res, next));

router.use('/product-listing-status', (req, res, next) => require('../admin-routes/product_listing_statuses.routes.js')(req, res, next));

router.use('/order-type', (req, res, next) => require('../admin-routes/order_type.routes.js')(req, res, next));

router.use('/package-type', (req, res, next) => require('../admin-routes/package_type.routes.js')(req, res, next));

router.use('/jurisdiction', (req, res, next) => require('../admin-routes/jurisdiction.routes.js')(req, res, next));

router.use('/tax-code', (req, res, next) => require('../admin-routes/tax_code_master.routes.js')(req, res, next));

router.use('/manufacturer', (req, res, next) => require('../admin-routes/manufacturer.routes.js')(req, res, next));

router.use('/account-type', (req, res, next) => require('../admin-routes/account_type.routes.js')(req, res, next));

router.use('/address-type', (req, res, next) => require('../admin-routes/address_type_master.routes.js')(req, res, next));

router.use('/document-type', (req, res, next) => require('../admin-routes/document_type_master.routes.js')(req, res, next));

router.use('/payout-schedule', (req, res, next) => require('../admin-routes/payout_schedule.routes.js')(req, res, next));

router.use('/product-condition', (req, res, next) => require('../admin-routes/product_conditions.routes.js')(req, res, next));

router.use('/model', (req, res, next) => require('../admin-routes/model.routes.js')(req, res, next));

router.use('/module', (req, res, next) => require('../admin-routes/module.routes.js')(req, res, next));

router.use('/profile-privilege', (req, res, next) => require('../admin-routes/profile-privilege.routes.js')(req, res, next));

router.use('/brand', (req, res, next) => require('../admin-routes/brand.routes.js')(req, res, next));

router.use('/web-version', (req, res, next) => require('../admin-routes/web_version.routes.js')(req, res, next));

router.use('/prefix-refno', (req, res, next) => require('../admin-routes/prefix_refno.routes.js')(req, res, next));

router.use('/profile', (req, res, next) => require('../admin-routes/profile.routes.js')(req, res, next));

router.use('/role-data-access', (req, res, next) => require('../admin-routes/role-data-access.routes.js')(req, res, next));

router.use('/cms', (req, res, next) => require('../admin-routes/cms.routes.js')(req, res, next));

router.use('/buyer', (req, res, next) => require('../admin-routes/buyer.routes.js')(req, res, next));

router.use('/seller', (req, res, next) => require('../admin-routes/seller.routes.js')(req, res, next));

router.use('/warehouse', (req, res, next) => require('../admin-routes/warehouse.routes.js')(req, res, next));

router.use('/warehousebin', (req, res, next) => require('../admin-routes/warehouse_bin.routes.js')(req, res, next));

router.use('/buyer-portal-user', (req, res, next) => require('../admin-routes/buyer-portal-user.routes.js')(req, res, next));

router.use('/seller-portal-user', (req, res, next) => require('../admin-routes/seller-portal-user.routes.js')(req, res, next));

router.use('/product', (req, res, next) => require('../admin-routes/product.routes.js')(req, res, next));

router.use('/part', (req, res, next) => require('../admin-routes/parts.routes.js')(req, res, next));

router.use('/parameter', (req, res, next) => require('../admin-routes/parameters.routes.js')(req, res, next));

router.use('/group', (req, res, next) => require('../admin-routes/group.routes.js')(req, res, next));

router.use('/subgroup', (req, res, next) => require('../admin-routes/subgroup.routes.js')(req, res, next));

router.use('/subnode', (req, res, next) => require('../admin-routes/subnode.routes.js')(req, res, next));

router.use('/group-part', (req, res, next) => require('../admin-routes/group-parts.routes.js')(req, res, next));

router.use('/subgroup-part', (req, res, next) => require('../admin-routes/subgroup-parts.routes.js')(req, res, next));

router.use('/subnode-part', (req, res, next) => require('../admin-routes/subnode-parts.routes.js')(req, res, next));

router.use('/buyer-product', (req, res, next) => require('../admin-routes/buyer-product.routes.js')(req, res, next));

router.use('/cart-item-status', (req, res, next) => require('../admin-routes/cart_item_status.routes.js')(req, res, next));

router.use('/checkout-item-status', (req, res, next) => require('../admin-routes/checkout_item_status.routes.js')(req, res, next));

router.use('/checkout-status', (req, res, next) => require('../admin-routes/checkout_status.routes.js')(req, res, next));

router.use('/warehouse-type', (req, res, next) => require('../admin-routes/warehouse_type.routes.js')(req, res, next));

router.use('/quote-type', (req, res, next) => require('../admin-routes/quote_type.routes.js')(req, res, next));

router.use('/reference-type', (req, res, next) => require('../admin-routes/reference_type.routes.js')(req, res, next));

router.use('/payment-method', (req, res, next) => require('../admin-routes/payment_method.routes.js')(req, res, next));

router.use('/checkout-type', (req, res, next) => require('../admin-routes/checkout_type.routes.js')(req, res, next));

router.use('/service-charge', (req, res, next) => require('../admin-routes/service_charge.routes.js')(req, res, next));



module.exports = router;
